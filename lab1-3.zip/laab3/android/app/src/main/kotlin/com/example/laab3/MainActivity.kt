package com.example.laab3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
